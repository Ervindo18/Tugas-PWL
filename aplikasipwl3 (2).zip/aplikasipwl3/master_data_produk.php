<?php
include "cek_login.php";
include "config.php";

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM produk WHERE id=$id");
    header("Location: produk_master.php");
    exit;
}

$search = isset($_GET['cari']) ? $_GET['cari'] : '';
$where = $search ? "WHERE nama_produk LIKE '%$search%'" : '';
$data = mysqli_query($conn, "SELECT * FROM produk $where");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Master Data Produk</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel ="stylesheet" href="css/master_data_produk.css">
</head>
<body>

    <h2>Master Data Produk</h2>

    <div class="form-and-dashboard-container">
        <form method="get">
            <input type="text" name="cari" placeholder="Cari produk..." value="<?= htmlspecialchars($search) ?>">
            <input type="submit" value="Cari">
            <a href="produk_input.php" class="btn btn-add">+ Tambah Produk</a>
        </form>
        <a href="dashboard.php" class="btn-dashboard">
            <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
        </a>
    </div>

    <table>
        <tr>
            <th>No</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
        <?php $no = 1; while ($row = mysqli_fetch_assoc($data)): ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $row['nama_produk'] ?></td>
            <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
            <td><?= $row['stok'] ?></td>
            <td class="aksi">
                <a href="produk_input.php?edit=<?= $row['id'] ?>">Ubah</a> |
                <a href="?hapus=<?= $row['id'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

</body>
</html>