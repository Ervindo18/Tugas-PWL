<!-- Footer -->
    <footer class="glass-dark text-white py-12 mt-16">
        <div class="max-w-7xl mx-auto px-6">
            <div class="text-center">
                <p class="text-sm">&copy; <?php echo date('Y'); ?> Made by Maulana Yusuf - 202243500894</p>
            </div>
        </div>
    </footer>
</body>
</html>