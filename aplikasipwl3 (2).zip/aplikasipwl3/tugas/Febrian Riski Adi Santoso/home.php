<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Home - Febrian</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: #e0f7fa;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            height: 100vh;
            margin: 0;
           
            color: #333;
        }
        .content {
            max-width: 600px;
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        h1 {
            font-size: 32px;
            color: #2c3e50;
        }
        p {
            margin-top: 15px;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="content">
        <h1>wellcome bruhhh ini website gue</h1>
        <p>Hallo dengan saya <strong>Febrian Riski Adi Santoso</strong>.<br> 
        Ini adalah website tugas Pemrograman Web Lanjut.<br>
        Silakan cek dan ricek aja maseeehhhh kanan ada file tugas atas ada kontak.</p>
    </div>
</body>
</html>
