<html>
	<head>
		<title>Tugas PW 2-3</title>
		<style>
			body {
				font-family: Arial, sans-serif;
				padding: 20px;
			}
		</style>
	</head>
	<body>
	<style>
        .centered {
           position: absolute;
           top: 50%;
           left: 50%;
           transform: translate(-50%, -50%);
           text-align: center;
}
    </style>
    
<div class="centered">

		<h1>Perkenalan</h1>

		<?php
			function perkenalan() {
				echo "Halo, nama saya febrian.<br>";
				echo "Saya mahasiswa Teknik Informatika.<br>";
				echo "Senang bisa belajar bersama kalian!";
			}

			perkenalan();
		?>

	</body>
</html>
