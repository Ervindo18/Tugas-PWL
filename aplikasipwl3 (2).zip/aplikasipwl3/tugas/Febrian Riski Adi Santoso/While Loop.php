<style>
        .centered {
           position: absolute;
           top: 50%;
           left: 50%;
           transform: translate(-50%, -50%);
           text-align: center;
}
    </style>
    
<div class="centered">
<?php

$i = 0;

while ($i < 10) 
{
  
    echo $i;
    $i++;
}
?>
