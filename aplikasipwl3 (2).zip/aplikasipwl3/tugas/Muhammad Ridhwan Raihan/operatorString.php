<div class="content-box">
    <?php
        
        $teks1 = "Aku Sedang Belajar";
        $teks2 = "Pemrograman WEB 2";
        $teks3 = "Menggunakan PHP";

        $hasil = $teks1 . $teks2 . $teks3;
        printf("hasil : %s<br/>", $hasil);
        $hasil = $teks1 . " " . $teks2 . " ". $teks3;
        echo "hasil : " . $hasil;
        
    ?>
</div>