<div class="sidebar">
  <ul>
    <li><a href="index.php?page=hello">Hello World</a></li>
    <li><a href="index.php?page=variabel">Variabel</a></li>
    <li><a href="index.php?page=variabelObject">Variabel Object</a></li>
    <li><a href="index.php?page=konstanta">Konstanta</a></li>
    <li><a href="index.php?page=operator">Operator</a></li>
    <li><a href="index.php?page=operatorPerbandingan">Operator Perbandingan</a></li>
    <li><a href="index.php?page=operatorString">Operator String</a></li>
    <li><a href="index.php?page=if_else">If Else</a></li>
    <li><a href="index.php?page=if_elseif_else">If Elseif Else</a></li>
    <li><a href="index.php?page=Switch">Switch Case</a></li>
    <li><a href="index.php?page=While_loop">While Loop</a></li>
    <li><a href="index.php?page=Do_whileLoop">Do-While Loop</a></li>
    <li><a href="index.php?page=ForLoop">For Loop</a></li>
    <li><a href="index.php?page=ForeachLoop">Foreac Loop</a></li>
    <li><a href="index.php?page=method_get">Method Get</a></li>    
    <li><a href="index.php?page=method_post">Method Post</a></li>    
    <li><a href="index.php?page=form_post">Form Post</a></li>
    <li><a href="index.php?page=methodPost">Latihan Method Post</a></li>    
    <li><a href="index.php?page=biodata">Biodata</a></li>
  </ul>
</div>
