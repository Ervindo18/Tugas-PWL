    <?php
    if (isset($_POST["ok"])) 
    {
        echo "Nama :". $_POST["nama"]. "<br />";
        echo "Umur :". $_POST["umur"];
    }
    ?>