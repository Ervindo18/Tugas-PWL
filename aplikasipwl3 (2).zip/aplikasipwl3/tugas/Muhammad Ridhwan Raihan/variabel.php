<div class="content-box">
<?php
    $nama = "Rdwn";
    $usia = 25;
    $hobi = array ("Mabar", "Mancing");

    echo "$nama berusia $usia tahun <br>";
    echo "Hobinya : $hobi[0], $hobi[1]";
?>
</div>