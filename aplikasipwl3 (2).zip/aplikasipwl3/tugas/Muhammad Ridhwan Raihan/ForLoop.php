<div class="content-box">
<?php
//inisialisasi nilai awal
    //jalankan selama memenuhi sayarat
    //execute setelah menjalankan blok
    for ($i = 0; $i <10; $i++)
    {
        echo $i;
    }

    //0123456789
?>
</div>