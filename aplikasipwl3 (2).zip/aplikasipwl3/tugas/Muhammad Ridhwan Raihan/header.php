<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Pemrograman Web Lanjut - Muhammad Ridhwan Raihan</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="header">
    <h1>WELCOME TO MY WEBSITE</h1>
  </div>
  <div class="subheader">
  <p>Website ini dibikin buat nampung tugas-tugas pemrograman web lanjut</p>
  </div>