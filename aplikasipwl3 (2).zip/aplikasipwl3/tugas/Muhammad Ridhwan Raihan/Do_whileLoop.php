<div class="content-box">
<?php
//inisialisasi nilai awal
    $i = 0;

    do {

        //jalankan program
        echo $i;
        $i++;
    } while ($i <10 ); //ulangi jika memenuhi syarat

    //0123456789
?>
</div>