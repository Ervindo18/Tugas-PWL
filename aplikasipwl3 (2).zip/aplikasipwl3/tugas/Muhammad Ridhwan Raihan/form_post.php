<!DOCTYPE html>
<html>
<head>
    <title>Penanganan Form</title>
</head>
<body>
    <form action="action_post" method="POST">
        Nama :<input type="text" name="nama" /><br />
        Umur :<input type="text" name="umur" /><br />
        <input type="submit" name="ok" value="OK" />
    </form>
</body>
</html>
