<div class="content-box">
    <?php echo "Hello World!"; ?>
</div>