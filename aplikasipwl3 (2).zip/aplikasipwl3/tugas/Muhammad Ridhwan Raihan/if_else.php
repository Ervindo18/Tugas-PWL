<div class="content-box">
<?php
    $nilai = 60;
    if ($nilai >=50)
        echo "Anda Lulus";
    else
        echo "Anda Tidak Lulus";
?>
</div>