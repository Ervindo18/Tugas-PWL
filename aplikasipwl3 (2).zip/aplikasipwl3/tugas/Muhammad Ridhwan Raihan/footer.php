<div class="footer">
  <p>&copy; Pemrograman Web Lanjut, Copyright Muhammad Ridhwan Raihan</p>
</div>
</body>
</html>
