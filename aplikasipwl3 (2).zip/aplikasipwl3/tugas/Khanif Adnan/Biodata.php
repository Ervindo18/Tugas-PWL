<div class="content">
<div style="padding: 20px;">
    <h1>Biodata Saya</h1>

    <div style="margin-top: 20px; display: flex; align-items: flex-start;">

        <div style="margin-right: 20px;">
            <img src="profil.png" alt="Foto Khanif Adnan" width="200" style="border-radius: 10px;">
        </div>
        <table style="border-collapse: collapse;">
            <tr>
                <td style="padding: 8px;"><strong>Nama</strong></td>
                <td style="padding: 8px;">: Khanif Adnan</td>
            </tr>
            <tr>
                <td style="padding: 8px;"><strong>NPM</strong></td>
                <td style="padding: 8px;">: 202243500808</td>
            </tr>
            <tr>
                <td style="padding: 8px;"><strong>Kelas</strong></td>
                <td style="padding: 8px;">: S6F</td>
            </tr>
            <tr>
                <td style="padding: 8px;"><strong>TTL</strong></td>
                <td style="padding: 8px;">: Tegal, 22 November 1999</td>
            </tr>
            <tr>
                <td style="padding: 8px;"><strong>Alamat</strong></td>
                <td style="padding: 8px;">: Jl. Raya Tengah No.1, RT. 08/01 Gedong, Pasar Rebo, Jakarta Timur</td>
            </tr>
            <tr>
                <td style="padding: 8px;"><strong>Pekerjaan</strong></td>
                <td style="padding: 8px;">: Mahasiswa</td>
            </tr>
            <tr>
                <td style="padding: 8px;"><strong>Hobi</strong></td>
                <td style="padding: 8px;">: Mancing, Joging</td>
            </tr>
        </table>
    </div>
</div>
</table>
</div> 
</div>

</body>
</html>

