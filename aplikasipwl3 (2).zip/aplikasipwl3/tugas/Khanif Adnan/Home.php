<div class="sidebar">
  <ul>
    <li><a href="index.php?page=Biodata">Biodata</a></li>
    <li><a href="index.php?page=HelloWorld">Hello World</a></li>
    <li><a href="index.php?page=Variabel">Variabel</a></li>
    <li><a href="index.php?page=Object">Variabel Object</a></li>
    <li><a href="index.php?page=konstanta">Konstanta</a></li>
    <li><a href="index.php?page=OperatorAritmatika">Operator Aritmatika</a></li>
    <li><a href="index.php?page=OperatorPerbandingan">Operator Perbandingan</a></li>
    <li><a href="index.php?page=OperatorString">Operator String</a></li>
    <li><a href="index.php?page=Kondisiif">Kondisi If</a></li>
    <li><a href="index.php?page=KondisiElseif">Kondisi Else If</a></li>
    <li><a href="index.php?page=KondisiSwitch">Kondisi Switch</a></li>
    <li><a href="index.php?page=WhileLoop">While Loop</a></li>
    <li><a href="index.php?page=DowhileLoop">Do While Loop</a></li>
    <li><a href="index.php?page=ForLoop">For Loop</a></li>
    <li><a href="index.php?page=ForeachLoop">Foreach Loop</a></li>
    <li><a href="index.php?page=FunctionByRef">Function Call By Reff</a></li>
    <li><a href="index.php?page=FunctionCallByValue">Function Call By Value</a></li> 
    <li><a href="index.php?page=FunctionParameter">Function Dengan Parameter</a></li> 
    <li><a href="index.php?page=FunctionParameterDefault">Function Dengan Parameter Default</a></li>       
    <li><a href="index.php?page=Soal1">Soal 1</a></li>
    <li><a href="index.php?page=Soal2">Soal 2</a></li>  
    <li><a href="index.php?page=Soal3">Soal 3</a></li>   
  </ul>
</div>

