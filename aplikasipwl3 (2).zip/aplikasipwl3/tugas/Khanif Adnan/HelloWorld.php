
<div class="content">
    <?php
        echo '<p>Hello World!</p>';
    ?>
</div>
