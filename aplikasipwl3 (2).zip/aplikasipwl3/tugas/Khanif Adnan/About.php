<div class="content">
    <h1 class="page-title"></h1>

    <div class="about-box" style="padding: 20px; line-height: 1.8;">

        <p>Halo! Saya adalah <strong>mahasiswa aktif Universitas Indraprasta PGRI (UNINDRA)</strong>
        </p>

    </div>
</div>
