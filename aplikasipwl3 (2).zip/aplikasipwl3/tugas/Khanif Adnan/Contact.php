<div class="content">
    <h1 class="page-title"></h1>

    <div class="about-box" style="padding: 20px; line-height: 1.8;">

        <p> Email :</strong> khanifadnan57@gmail.com <br><br>
            HP :</strong> (+62) 896-5802-2825
        </p>

    </div>
</div>

        </p>

    </div>
</div>
