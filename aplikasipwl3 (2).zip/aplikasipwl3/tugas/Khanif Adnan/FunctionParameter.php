<div class="content">
    <div>
        <div>
            <h3>Function Dengan Parameter</h3><br>

            <div>
                <p>Menambahkan parameter dalam sebuah function diantara ( )</p><br>

                <div>
                    <h3>Output:</h3><br>
                    <?php
                    function salam($nama)
                    {
                        echo "Halo $nama<br>";
                    }

                    salam("Chad Smith");
                    salam("John Frusciante");
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>