<div class="content">
    <?php
    $nama = "Khanif Adnan";
    $usia = 25;
    $hobi = array("Joging", "Mendengar Musik");

    echo "$nama berusia $usia tahun <br/>";
    // Upin berusia 5 tahun
    echo "Hobinya : $hobi[0], $hobi[1]";
    // Hobinya : membaca, mewarnai
    ?>
</div>