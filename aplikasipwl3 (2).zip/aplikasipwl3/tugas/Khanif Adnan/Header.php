<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Khanif Adnan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container-navbar">
    <h2>(202243500808) - (Khanif Adnan)</h2>
</div>

<div class="main-content">
