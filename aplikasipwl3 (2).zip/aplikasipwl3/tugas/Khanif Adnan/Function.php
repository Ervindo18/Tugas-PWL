<div class="content">

    <div>
        <div>
            <h3>Function Sendiri</h3>

            <div>
                <h3>Awali dengan kata function, kemudian berikan nama function dan kita dapat menambahkan parameter jika diperlukan. Blok program berada diantara { }</h3>

                <div>
                    <h3>Output:</h3>
                    <?php
                    function biodata()
                    {
                        $nama = "Khanif Adnan";
                        $umur = 25;

                        echo "Nama: $nama <br>";
                        echo "Umur: $umur tahun <br>";
                    }

                    biodata();
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>