<div class="content-box">
  <h2>Hello World</h2>
  <?php echo "【﻿Ｈｅｌｌｏ　Ｗｏｒｌｄ】"; ?>
</div>
