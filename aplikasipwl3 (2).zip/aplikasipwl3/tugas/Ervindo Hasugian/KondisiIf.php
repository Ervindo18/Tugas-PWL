<?php

$nilai = 60;
    if ($nilai >=50)
        echo "𝘼𝙉𝘿𝘼 𝙇𝙐𝙇𝙐𝙎";
    else
        echo "𝘼𝙉𝘿𝘼 𝙏𝙄𝘿𝘼𝙆 𝙇𝙐𝙇𝙐𝙎";

?>