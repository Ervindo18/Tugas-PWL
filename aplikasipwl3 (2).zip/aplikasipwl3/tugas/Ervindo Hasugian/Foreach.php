<?php

$list_hari = array(
        "𝐒𝐄𝐍𝐈𝐍",
        "𝐒𝐄𝐋𝐀𝐒𝐀",
        "𝐑𝐀𝐁𝐔",
        "𝐊𝐀𝐌𝐈𝐒",
        "𝐉𝐔𝐌𝐀𝐓",
        "𝐒𝐀𝐁𝐓𝐔",
        "𝐌𝐈𝐍𝐆𝐆𝐔"    
    );
    //perulangan menggunakan foreach
    foreach($list_hari as $hari)
    {
        //array $list_hari dipecah menjadi $hari
        echo $hari . ", " ;
    }

    //Senin, Selasa, Rabu, Kamis, Jumat, Sabtu, Mingu,

    ?>