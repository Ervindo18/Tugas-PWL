<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">

    <title>Latihan PHP</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .content { margin-top: 20px; }
    </style>
</head>
<body></body>