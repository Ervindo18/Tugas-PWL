<?php

$hari = 3;
    if($hari == 1) echo "Senin";
    elseif($hari == 2) echo "Selasa";
    elseif($hari == 3) echo "𝐑𝐀𝐁𝐔";
    elseif($hari == 4) echo "Kamis";
    elseif($hari == 5) echo "Jumat";
    elseif($hari == 6) echo "Sabtu";
    elseif($hari == 7) echo "Minggu";
    else echo "Salah Kode Hari";

?>