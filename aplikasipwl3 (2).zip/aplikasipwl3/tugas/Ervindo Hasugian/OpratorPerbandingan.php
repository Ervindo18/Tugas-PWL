<?php

$bil1 = 100;
            $bil2 = 20;
            $teks1 = "PHP";
            $teks2 = "PHP";

            printf("%d == %d 𝐇𝐀𝐒𝐈𝐋𝐍𝐘𝐀 %d<br/>",$bil1, $bil2, $bil1 == $bil2);
            //100 == 20 𝐇𝐀𝐒𝐈𝐋𝐍𝐘𝐀 0
            printf("%d != %d 𝐇𝐀𝐒𝐈𝐋𝐍𝐘𝐀 %d<br/>",$bil1, $bil2, $bil1 != $bil2);
            //100 != 20 𝐇𝐀𝐒𝐈𝐋𝐍𝐘𝐀 1
            printf("%d >= %d 𝐇𝐀𝐒𝐈𝐋𝐍𝐘𝐀 %d<br/>",$bil1, $bil2, $bil1 >= $bil2);
            //100 >= 20 𝐇𝐀𝐒𝐈𝐋𝐍𝐘𝐀 1
            printf("%s == %s 𝐇𝐀𝐒𝐈𝐋𝐍𝐘𝐀 %d<br/>",$teks1, $teks2, $teks1 == $teks2);
            //PHP == php 𝐇𝐀𝐒𝐈𝐋𝐍𝐘𝐀 0
            printf("%s != %s 𝐇𝐀𝐒𝐈𝐋𝐍𝐘𝐀 %d<br/>",$teks1, $teks2, $teks1 != $teks2);
            //PHP != php 𝐇𝐀𝐒𝐈𝐋𝐍𝐘𝐀 1

            ?>