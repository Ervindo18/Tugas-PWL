<div class="content-box" style="display: flex; gap: 20px; padding: 20px;">
  <div class="foto" style="flex: 1; text-align: center;">
    <h3>𝐌𝐘 𝐅𝐎𝐓𝐎</h3>
    <img src="Doo.jpg.jpeg" width="200" alt="Foto Doo" style="border:2px solid #ccc; border-radius: 0%; padding:5px;">
  </div>
  <div class="biodata" style="flex: 2; background-color: #3e70e6; padding: 20px; border-radius: 10px;">
    <h1 style="border-bottom: 2px solid #333; padding-bottom: 5px;">▀▄▀▄▀▄ 𝐁𝐈𝐎𝐃𝐀𝐓𝐀 𝐒𝐀𝐘𝐀 ▄▀▄▀▄▀</h1>
    <p><strong>𝐍𝐀𝐌𝐀</strong>        : 𝐄𝐑𝐕𝐈𝐍𝐃𝐎 𝐇𝐀𝐒𝐔𝐆𝐈𝐀𝐍</p>
    <p><strong>𝐍𝐏𝐌</strong>         : 𝟐𝟎𝟐𝟐𝟒𝟑𝟓𝟎𝟎𝟖𝟒𝟎</p>
    <p><strong>𝐊𝐄𝐋𝐀𝐒</strong>       :  𝐒𝟔𝐅</p>
    <p><strong>𝐓𝐓𝐋</strong>         : 𝐉𝐀𝐊𝐀𝐑𝐓𝐀 𝟏𝟖 𝐀𝐏𝐑𝐈𝐋 𝟐𝟎𝟎𝟏</p>
    <p><strong>𝐀𝐋𝐀𝐌𝐀𝐓</strong>      : 𝐁𝐄𝐊𝐀𝐒𝐈 𝐔𝐓𝐀𝐑𝐀 𝐁𝐀𝐁𝐄𝐋𝐀𝐍 𝐈𝐍𝐃𝐀𝐇</p>
    <p><strong>𝐏𝐄𝐊𝐄𝐑𝐉𝐀𝐀𝐍</strong>   : 𝐓𝐄𝐊𝐍𝐈𝐒𝐈</p>
    <p><strong>𝐄𝐌𝐀𝐈𝐋</strong>       : 𝐄𝐑𝐕𝐈𝐍𝐃𝐎𝐇𝐀𝐒𝐔𝐆𝐈𝐀𝐍@𝐆𝐌𝐀𝐈𝐋.𝐂𝐎𝐌</p>
    <p><strong>𝐇𝐎𝐁𝐈</strong>        : 𝐆𝐀𝐌𝐄 & 𝐅𝐔𝐓𝐒𝐀𝐋</p>
  </div>
</div>
