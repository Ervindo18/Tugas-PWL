<div class="footer">
  <p>&copy; <?php echo date("Y"); ?> Ervindo Hasugian | All Rights Reserved</p>
</div>
