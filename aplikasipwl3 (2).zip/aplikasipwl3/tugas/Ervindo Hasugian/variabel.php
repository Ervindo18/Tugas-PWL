<div class="content-box">
  <h2>Variabel</h2>
  <?php
    $nama = "𝐄𝐑𝐕𝐈𝐍𝐃𝐎 𝐇𝐀𝐒𝐔𝐆𝐈𝐀𝐍";
    $umur = 24;
    echo "𝐍𝐀𝐌𝐀 𝐒𝐀𝐘𝐀 $nama 𝐃𝐀𝐍 𝐔𝐌𝐔𝐑 𝐒𝐀𝐘𝐀 $umur 𝐓𝐀𝐇𝐔𝐍.";
  ?>
</div>
