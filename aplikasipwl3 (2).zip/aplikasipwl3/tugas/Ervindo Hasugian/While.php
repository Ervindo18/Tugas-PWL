<?php

//inisialisasi nilai awal
    $i = 0;

    while($i < 10) //lakukan selama memenuhi syarat
    {
        //jalankan blok program
        echo $i ;
        $i++ ;
    }

    //0123456789

    ?>