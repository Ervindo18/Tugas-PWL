<div class="sidebar">
  <ul>
    <li><a href="index.php?page=biodata">Biodata</a></li>
    <li><a href="index.php?page=hello">Hello World</a></li>
    <li><a href="index.php?page=variabel">Variabel</a></li>
    <li><a href="index.php?page=Object"> Object</a></li>
    <li><a href="index.php?page=OpratorAritmatika"> Oprator Aritmatika</a></li>
    <li><a href="index.php?page=OpratorPerbandingan"> Oprator Perbandingan</a></li>
    <li><a href="index.php?page=OpratorString"> Oprator String</a></li>
    <li><a href="index.php?page=KondisiIf"> Kondisi If</a></li>
    <li><a href="index.php?page=KondisiElself"> Kondisi Elself</a></li>
    <li><a href="index.php?page=Switch"> Switch</a></li>
    <li><a href="index.php?page=While"> While</a></li>
    <li><a href="index.php?page=DO"> Do</a></li>
    <li><a href="index.php?page=For"> For</a></li>
    <li><a href="index.php?page=Foreach"> Foreach</a></li>
    <li><a href="index.php?page=methodPost">methodPost 1</a></li>
    <li><a href="index.php?page=latihan2">Latihan 2</a></li>
    <li><a href="index.php?page=latihan3">Latihan 3</a></li>
    
  </ul>
</div>
