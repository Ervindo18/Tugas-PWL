<div class="main-content">
    <div class="sidebar">
        <h3>Daftar latihan</h3>
        <ul>
            <li><a href="index.php?page=Biodata">Biodata</a></li>
            <li><a href="index.php?page=Helloword">Hello World</a></li>
            <li><a href="index.php?page=Variabel">Variabel</a></li>
            <li><a href="index.php?page=Variabel_object">Variabel Object</a></li>
            <li><a href="index.php?page=Konstanta">Konstanta</a></li>
            <li><a href="index.php?page=Operator_naik_turun">Operator Aritmetika</a></li>
            <li><a href="index.php?page=Operator_pembandingan">Operator Perbandingan</a></li>
            <li><a href="index.php?page=Operator_string">Operator String</a></li>
            <li><a href="index.php?page=Kondisi_if">Kondisi If</a></li>
            <li><a href="index.php?page=Kondisi_Elseif">Kondisi Elseif</a></li>
            <li><a href="index.php?page=Kondisi_Switch-case">Kondisi Switch</a></li>
            <li><a href="index.php?page=Perulangan_While-loop">While Loop</a></li>
            <li><a href="index.php?page=Perulangan_Do-while-loop">Do While Loop</a></li>
            <li><a href="index.php?page=Perulangan-foor-loop">For Loop</a></li>
            <li><a href="index.php?page=Perulangan_Foreach-loop">Foreach Loop</a></li>
            <li><a href="index.php?page=Latihan2">Latihan 2</a></li>
            <li><a href="index.php?page=Latihan3">Latihan 3</a></li>
            <li><a href="index.php?page=Methodpost">Form Biodata</a></li>
        </ul>
    </div>
<