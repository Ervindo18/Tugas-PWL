        <div class="content">
          <?php
             $i = 0 ;
             
             do{
                   echo $i;
                   $i++ ;

               } while ($i < 10);
          ?>