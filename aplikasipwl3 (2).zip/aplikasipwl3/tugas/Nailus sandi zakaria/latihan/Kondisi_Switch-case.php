          <?php
               $bulan = 2;
               switch ($bulan)
               {
                    case 1 : echo "Januari"; break;
                    case 2 : echo "Januari"; break;
                    case 3 : echo "Januari"; break;
                    case 4 : echo "Januari"; break;
                    case 5 : echo "Januari"; break;
                    case 6 : echo "Januari"; break;
                    case 7 : echo "Januari"; break;
                    case 8 : echo "Januari"; break;
                    case 9 : echo "Januari"; break;
                    case 10 : echo "Januari"; break;
                    case 11 : echo "Januari"; break;
                    case 12 : echo "Januari"; break;
               }
                
          ?>