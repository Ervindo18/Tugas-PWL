          <?php
              $nama = "zaka";
              $usia = 22;
              $hobi = array("Nonton Film", "Main Game","Mendaki");

              echo "$nama berusia $usia tahun <br/>";

              echo "Hobinya : $hobi[0], $hobi[1], $hobi[2]";
          ?>       