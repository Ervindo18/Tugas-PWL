        <div class="content">
            <?php
                $bil1 = 110;
                $bil2 = 25;
        
                $hasil = $bil1 + $bil2;
                echo "$bil1 + $bil2 = $hasil<br/>";
        
                $hasil = $bil1 - $bil2;
                echo "$bil1 $bil2 = $hasil<br/>";
         
                $hasil = $bil1 * $bil2;
                echo "$bil1 * $bil2 = $hasil<br/>";
        
                $hasil = $bil1 / $bil2;
                echo "$bil1 / $bil2 = $hasil<br/>";
        
                $hasil = $bil1 % $bil2;
                echo "$bil1 % $bil2 = $hasil<br/>";
        
                $hasil = $bil1++;
                echo "$bil1++ = $hasil<br/>";
        
                $hasil = $bil2--;
                echo "$bil2-- = $hasil<br/>";       
            ?>
        