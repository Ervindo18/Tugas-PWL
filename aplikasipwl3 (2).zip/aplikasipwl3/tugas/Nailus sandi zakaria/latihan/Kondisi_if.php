          <?php
               $nilai = 60;
                 if($nilai >= 50)
                   echo "Anda lulus";
                 else
                   echo "Anda tidak lulus";
          ?>
        